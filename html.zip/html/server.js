let express = require('express')
let bodyParser = require('body-parser')
let mongoose = require('mongoose')
mongoose.connect("mongodb://localhost/otroo", {useNewUrlParser:true,useUnifiedTopology: true })
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch(() => console.log('Connexion à MongoDB échouée !'));
let app = express()

const port = process.env.PORT || 80;


app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static('public'))
app.set('view engine','ejs')


app.get('/', (request, reponse) =>{
    reponse.render('pages/index')
})
app.get('/events', (request, reponse) =>{
    reponse.render('pages/events')
})
app.get('/about', (request, reponse) =>{
    reponse.render('pages/about')
})
app.get('/contact', (request, reponse) =>{
    reponse.render('pages/contact')
})
app.get('/rooms', (request, reponse) =>{
    reponse.render('pages/rooms')
})
app.get('/index', (request, reponse) =>{
    reponse.render('pages/index')
})

app.listen(port)